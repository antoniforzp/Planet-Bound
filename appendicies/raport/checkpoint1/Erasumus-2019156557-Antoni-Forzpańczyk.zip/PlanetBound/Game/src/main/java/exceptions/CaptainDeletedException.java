package exceptions;

public class CaptainDeletedException extends Exception {
}
