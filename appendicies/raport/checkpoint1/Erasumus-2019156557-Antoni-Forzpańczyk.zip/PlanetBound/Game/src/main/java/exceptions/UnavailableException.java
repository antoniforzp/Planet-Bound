package exceptions;

public class UnavailableException extends Exception {
}
