package walker;

public interface IWalker {
    void moveTowardsDestination();

    boolean moveOwn(int x, int y);
}
