package walker.alien.aliens;

import walker.alien.Alien;

public class BlueAlien extends Alien {

    public BlueAlien() {
        this.attackDown = 3;
        this.attackUp = 5;

        this.deathDown = 3;
        this.deathUp = 5;
    }
}
