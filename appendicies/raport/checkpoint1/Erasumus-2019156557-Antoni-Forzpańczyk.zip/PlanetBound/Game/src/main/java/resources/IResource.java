package resources;

public interface IResource {
    ResourceType getType();
}
