package ship;

public enum CrewMembers {
    Captain,                       //gold star
    NavigationOfficer,             //blue circle
    LandingPartyOfficer,           //red rhombus
    ShieldOfficer,                 //purple triangle
    WeaponOfficer,                 //orange pentagon
    CargoOfficer                   //green hexagon
}