package walker.alien.aliens.testing;

import walker.alien.Alien;

public class BadassAlien extends Alien {
    public BadassAlien() {
        this.attackDown = 1;
        this.attackUp = 6;

        this.deathDown = 0;
        this.deathUp = 0;
    }
}
