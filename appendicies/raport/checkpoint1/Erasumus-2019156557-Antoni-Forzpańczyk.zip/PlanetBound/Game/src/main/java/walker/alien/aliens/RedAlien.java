package walker.alien.aliens;

import walker.alien.Alien;

public class RedAlien extends Alien {
    public RedAlien() {
        this.attackDown = 5;
        this.attackUp = 6;

        this.deathDown = 1;
        this.deathUp = 2;
    }
}
