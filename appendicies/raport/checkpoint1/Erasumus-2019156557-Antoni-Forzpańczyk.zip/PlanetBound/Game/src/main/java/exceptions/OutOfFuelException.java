package exceptions;

public class OutOfFuelException extends Exception {
}
