package resources;

public enum ResourceType {
    Black,
    Blue,
    Green,
    Red,
    Artifact
}
