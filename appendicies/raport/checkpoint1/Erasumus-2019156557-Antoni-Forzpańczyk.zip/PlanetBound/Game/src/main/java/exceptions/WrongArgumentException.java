package exceptions;

public class WrongArgumentException extends Exception {
}
