package app;

public interface IController {
}
